#!/bin/bash

# (Optional) Change directory to Practical-1 to make sure you are in the right folder 
cd ~/Desktop/Practical-1

# Create a new directory called exercise_4
mkdir -p exercise_4

# Change to the exercise_4 directory
cd exercise_4

# Copy the file fruits_vegetables.txt into the current directory (assuming it's in the parent directory)
cp ../fruits_vegetables.txt .

# Sort the list of fruits and vegetables alphabetically and save it in sorted_fruits_vegetables.txt
sort fruits_vegetables.txt > sorted_fruits_vegetables.txt
echo "Sorted list saved in sorted_fruits_vegetables.txt:"

# Display the sorted list
cat sorted_fruits_vegetables.txt

# Sort the list in descending alphabetical order and save it in sorted_desc_fruits_vegetables.txt
sort -r fruits_vegetables.txt > sorted_desc_fruits_vegetables.txt
echo "Sorted list in descending order saved in sorted_desc_fruits_vegetables.txt:"

# Display the sorted list in descending order
cat sorted_desc_fruits_vegetables.txt

# Sort the list with unique words and save it in unique_fruits_vegetables.txt
sort -u fruits_vegetables.txt > unique_fruits_vegetables.txt
echo "Sorted list with unique words saved in unique_fruits_vegetables.txt:"

# Display the sorted unique list
cat unique_fruits_vegetables.txt