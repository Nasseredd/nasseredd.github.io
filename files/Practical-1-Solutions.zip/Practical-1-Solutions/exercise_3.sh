#!/bin/bash

# (Optional) Change directory to Practical-1 to make sure you are in the right folder 
cd ~/Desktop/Practical-1

# Create a new directory called exercise_3
mkdir exercise_3

# Change to the exercise_3 directory
cd exercise_3

# Create a text file and name it file1.txt
touch file1.txt

# Append the text of university_of_lorraine.txt to file1.txt (assuming university_of_lorraine.txt is in the parent directory)
cat ../university_of_lorraine.txt >> file1.txt

# Use the wc command to answer the questions
echo "Word count results for file1.txt:"

# Display the number of lines
# In your terminal, you can directly run the command `wc -l < file1.txt` to display the number of lines.
# However, in the script, we assign the result to the variable `lines` in order to store the output of the `wc` command.
# This allows us to use the result later in the script, such as printing it with the `echo` command.
lines=$(wc -l < file1.txt)
echo "Number of lines: $lines"

# Display the number of words
words=$(wc -w < file1.txt)
echo "Number of words: $words"

# Display the number of characters
characters=$(wc -m < file1.txt)
echo "Number of characters: $characters"

# Output
# Word count results for file1.txt:
# Number of lines: 5
# Number of words: 162
# Number of characters: 1140