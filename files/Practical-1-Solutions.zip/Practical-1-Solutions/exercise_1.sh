#!/bin/bash

# Change to Practical-1 directory
cd ~/Desktop/Practical-1

# Create a new directory called exercise_1
mkdir exercise_1

# Change to exercise_1 directory
cd exercise_1

# Create 3 text files
touch file1.txt file2.txt file3.txt

# Append the text of dump_text.txt into file2.txt (assuming dump_text.txt exists in the Practical-1 directory)
cat ../dump_text.txt >> file2.txt

# Script finished
echo "All tasks completed."