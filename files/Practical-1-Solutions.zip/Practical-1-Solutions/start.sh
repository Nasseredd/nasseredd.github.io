#!/bin/bash

# Change directory to Desktop (or Bureau)
cd ~/Desktop

# Download Practical-1/ directory (assuming it's from a remote source, replace with actual download command if needed)
wget https://nasseredd.github.io/files/Practical-1.zip -O Practical-1.zip
unzip Practical-1.zip
# If Practical-1 is already present, skip the above step