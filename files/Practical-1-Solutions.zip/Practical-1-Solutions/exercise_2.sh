#!/bin/bash

# (Optional) Change directory to Practical-1 to make sure you are in the right folder 
cd ~/Desktop/Practical-1

# Create a new directory called exercise_2
mkdir exercise_2

# Change to the exercise_2 directory
cd exercise_2

# Create a text file and name it myfile.txt
touch myfile.txt

# Append the text of inria.txt to myfile.txt (assuming inria.txt is in the parent directory)
cat ../inria.txt >> myfile.txt

# Display lines that contain the terms: "Inria", "Alors", or "mission"
# The grep command is used with the -E option (for extended regular expressions) to search for lines containing any of the terms "Inria", "Alors", or "mission". 
# The | symbol is used as an "OR" operator.
grep -E "Inria|Alors|mission" myfile.txt

# You can also display lines that contains each term at a time
# The -e option in the echo command allows for special characters like \n (newline) to be used, so that the output is spaced properly between each set of results.
# echo "Lines containing 'Inria':"
# grep "Inria" myfile.txt
# echo -e "\nLines containing 'Alors':"
# grep "Alors" myfile.txt
# echo -e "\nLines containing 'mission':"
# grep "mission" myfile.txt