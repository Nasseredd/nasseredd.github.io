#!/bin/bash

# (Optional) Change directory to Practical-1 to make sure you are in the right folder 
cd ~/Desktop/Practical-1

# Create a new directory called exercise_5 and change to it
mkdir -p exercise_5
cd exercise_5

# Create a new file named my_script.sh
touch my_script.sh

# Open the file with the native editor (use `nano`, `vim`, or any editor of your choice)
# Uncomment one of the lines below based on the editor you prefer:

# For nano (a terminal-based text editor):
# nano my_script.sh

# For vim:
# vim my_script.sh

# Once you've saved the file, make the script executable:
chmod +x my_script.sh

# Run the script:
./my_script.sh
