#!/bin/bash

# (Optional) Change directory to 
cd ~/Desktop/

# Download Practical-2/ directory (assuming it's from a remote source, replace with actual download command if needed)
wget https://nasseredd.github.io/files/Practical-2.zip -O Practical-2.zip
unzip Practical-2.zip
# If Practical-2 is already present, skip the above step

# (Optional) Change directory to Practical-2 to make sure you are in the right folder 
cd Practical-2

# Create a new directory and shell script for exercice_6
mkdir exercise_6
touch exercise_6/exercise_6.sh

# Create a new directory and shell script for exercice_7
mkdir exercise_7
touch exercise_7/exercise_7.sh

# Create a new directory and shell script for exercice_8
mkdir exercise_8
touch exercise_8/exercise_8.sh

# Create a new directory and shell script for exercice_9
mkdir exercise_9
touch exercise_9/exercise_9.sh