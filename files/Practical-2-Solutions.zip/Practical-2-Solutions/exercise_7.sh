#!/bin/bash

# Hardcoded username and password (ground truth)
correct_username="ned"
correct_password="nlp2024"

# Prompt the user to enter a username
echo "Enter your username: "
read entered_username

# Prompt the user to enter a password (input hidden)
# The -s option for read ensures that the password input is hidden for security purposes.
echo "Enter your password: "
read -s entered_password

# Check if the entered credentials match the hardcoded ones
if [[ "$entered_username" == "$correct_username" && "$entered_password" == "$correct_password" ]]; then
    echo "Authentication successful. Welcome, $entered_username!"
else
    echo "Access denied. Incorrect username or password."
fi

# After creating the script, you need to grant execute permissions to exercise_7.sh file FROM YOUR TERMINAL using the following command:
# chmod +x exercise_7.sh