#!/bin/bash

# List all files and directories in the current directory
for item in *; do
    if [ -d "$item" ]; then
        echo "$item is a directory"
    elif [ -f "$item" ]; then
        echo "$item is a file"
    fi
done

# After creating the script, you need to grant execute permissions to exercise_8.sh file FROM YOUR TERMINAL using the following command:
# chmod +x exercise_8.sh
