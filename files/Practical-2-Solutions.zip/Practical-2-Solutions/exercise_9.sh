#!/bin/bash

# (Optional) Change directory to Practical-2 to make sure you are in the right folder 
cd ~/Desktop/Practical-2

# Create a directory named exercise_9
mkdir exercise_9

# Change to the exercise_9 directory
cd exercise_9

# Create subdirectories named text_files, French, English
mkdir -p text_files
mkdir -p French
mkdir -p English

# Generate 100 .txt files with random filenames between 10 and 10,000
for i in {1..100}; do
    random_number=$((RANDOM % 9991 + 10)) # Generates a random number between 10 and 10,000
    touch text_files/$random_number.txt
done

# Move odd-numbered files to French/ and even-numbered files to English/
odd_count=0
even_count=0

for file in text_files/*.txt; do
    filename=$(basename "$file" .txt)
    
    if (( filename % 2 == 0 )); then
        mv "$file" English/
        ((even_count++))
    else
        mv "$file" French/
        ((odd_count++))
    fi
done

# Display how many files were moved to each subdirectory
echo "Files moved to French/ directory: $odd_count"
echo "Files moved to English/ directory: $even_count"

# In English/ directory, create a subdirectory named old/
mkdir -p English/old

# Copy files from English/ to old/ whose filenames are divisible by 5
for file in English/*.txt; do
    filename=$(basename "$file" .txt)
    
    if (( filename % 5 == 0 )); then
        cp "$file" English/old/
    fi
done

echo "Script completed successfully."

# After creating the script, you need to grant execute permissions to exercise_9.sh file FROM YOUR TERMINAL using the following command:
# chmod +x exercise_9.sh