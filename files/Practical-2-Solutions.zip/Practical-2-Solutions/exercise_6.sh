#!/bin/bash

# Prompt the user to enter a number
echo "Please enter a number: "
read number

# Check if the entered number is even or odd using an if-else statement
if (( number % 2 == 0 )); then
    echo "The number $number is even."
else
    echo "The number $number is odd."
fi

# After creating the script, you need to grant execute permissions to exercise_6.sh file FROM YOUR TERMINAL using the following command:
# chmod +x exercise_6.sh