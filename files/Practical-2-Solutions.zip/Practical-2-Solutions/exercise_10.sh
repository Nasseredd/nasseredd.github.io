#!/bin/bash

# (Optional) Change directory to Practical-2 to make sure you are in the right folder 
cd ~/Desktop/Practical-2/run

# Default stage
default_stage=2

# Ask user to specify the stage or use the default
echo "Please specify the stage (0 to 3), or press Enter to use the default stage ($default_stage):"
read stage

# If no input is provided, use the default stage
if [ -z "$stage" ]; then
    stage=$default_stage
    echo "No input provided. Using default stage: $stage"
fi

# Function to run the appropriate script based on the stage
run_stage() {
    if [ "$1" -eq 0 ]; then
        echo "Running: python3 load_dataset.py"
        python3 load_dataset.py
    elif [ "$1" -eq 1 ]; then
        echo "Running: python3 parsing_data.py"
        python3 parsing_data.py
    elif [ "$1" -eq 2 ]; then
        echo "Running: python3 train.py"
        python3 train.py
    elif [ "$1" -eq 3 ]; then
        echo "Running: python3 eval.py"
        python3 eval.py
    else
        echo "Invalid stage! Please choose between 0 and 3."
        exit 1
    fi
}

# Run the scripts starting from the specified stage and continue until stage 3
while [ "$stage" -le 3 ]; do
    run_stage "$stage"
    stage=$((stage + 1))  # Increment the stage
done
