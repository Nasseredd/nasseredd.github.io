import json
import time
import argparse
from tqdm import tqdm
from pathlib import Path

def load_configs(config_file_name: str = 'configs.json') -> dict:
    """Loads and returns configurations from a JSON file located relative to the script directory."""
    # Resolve the path to 'configs.json' relative to the script's location
    script_dir = Path(__file__).resolve().parent
    config_file_path = script_dir / config_file_name  # Removed extra 'running'

    try:
        with open(config_file_path, 'r') as file:
            configs = json.load(file)
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file not found: {config_file_path}")
    return configs

def train_model(shcope_n: int):
    """Simulates a machine learning model training process."""
    for epoch in tqdm(range(shcope_n), desc="Training: "):
        time.sleep(1)  # Simulating time taken per epoch

def parse_args():
    """Parses command-line arguments."""
    parser = argparse.ArgumentParser(description="Train a machine learning model")
    parser.add_argument('--shcope_n', type=int, help="Number of epochs for training")
    return parser.parse_args()

def main():
    """Main function to parse arguments, load configurations if needed, and start training."""
    args = parse_args()

    if args.shcope_n is not None:
        shcope_n = args.shcope_n
    else:
        configs = load_configs()  # Loads configs from the path relative to the script
        shcope_n = configs.get('shcope_n', 10)  # Fallback to 10 if not in configs
    
    train_model(shcope_n)

if __name__ == "__main__":
    main()
