import json
import time
import argparse
from tqdm import tqdm
from pathlib import Path

def load_configs(config_file_name: str = 'configs.json') -> dict:
    """Loads and returns configurations from a JSON file located relative to the script directory."""
    # Resolve the path to 'configs.json' relative to the script's location
    script_dir = Path(__file__).resolve().parent
    config_file_path = script_dir / config_file_name  # Removed extra 'running'

    try:
        with open(config_file_path, 'r') as file:
            configs = json.load(file)
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file not found: {config_file_path}")
    return configs

def parsing_dataset():

    for i in tqdm(range(10), desc="Parsing Dataset: "):
        time.sleep(1)

if __name__ == "__main__":
    parsing_dataset()